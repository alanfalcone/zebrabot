
def detectar_zebra(time_casa, time_fora):
    # Lógica simplificada para detectar zebra
    # Exemplo: se time grande perdeu para pequeno
    grandes = ["River Plate", "Boca Juniors", "Racing", "San Lorenzo"]
    pequenos = ["Arsenal Sarandí", "Platense", "Sarmiento", "Barracas Central"]

    if time_fora in grandes and time_casa in pequenos:
        return f"Zebra detectada: {time_casa} venceu {time_fora}"
    return "Sem zebra detectada"
