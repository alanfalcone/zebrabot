
# Configurações do ZebraBot

TELEGRAM_TOKEN = "SUA_CHAVE_AQUI"
