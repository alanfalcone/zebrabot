
from utils.zebra_logic import detectar_zebra

def main():
    print("Iniciando ZebraBot...")
    resultado = detectar_zebra("Independiente", "River Plate")
    print("Resultado:", resultado)

if __name__ == "__main__":
    main()
