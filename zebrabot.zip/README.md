
# ZebraBot

🤖 Bot de IA para previsão de zebras na Liga Argentina

### Funcionalidades:
- Detecta resultados inesperados com base nos clubes considerados grandes e pequenos.
- Pode ser integrado ao Telegram.
